package DrinkB;
import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import java.util.StringTokenizer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Order{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	//private JLabel lbluser_id,lblmid,lblorder_id,lblday;
	private JLabel lblorder_id,lblcustomer_id,lbldrinks_id,lblqty,lblprice_perqty;
	//private JTextField txtuser_id,txtmid,txtday,txtorder_id;
	//private Choice user_id,order_id,mid;
	private JTextField txtorder_id,txtcustomer_id,txtdrinks_id,txtqty,txtprice_perqty;
	private Choice customer_id,drinks_id;
	private List UserOrderIDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public Order(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		lblorder_id=new JLabel("Order ID");
		lblcustomer_id=new JLabel("Customer ID");
		lbldrinks_id=new JLabel("Drinks ID");
		lblqty=new JLabel("quantity");
		lblprice_perqty=new JLabel("priceperquantity");
		//order_id=new Choice();
		customer_id=new Choice();
		drinks_id=new Choice();
		txtorder_id=new JTextField(15);
		txtcustomer_id=new JTextField(15);
		txtdrinks_id=new JTextField(15);
		txtqty=new JTextField(8);
		txtprice_perqty=new JTextField(8);
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","it19737110","vasavi");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loaduserOrderIDs() {
		try {
			UserOrderIDList.removeAll();
			rs=statement.executeQuery("select * from torder");
			while(rs.next()) {
				UserOrderIDList.add(rs.getString("customer_id")+"->"+rs.getString("drinks_id"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}
	/*public void loadorders() {
		try {
			order_id.removeAll();
			rs=statement.executeQuery("select * from torder");
			while(rs.next()) {
				order_id.add(rs.getString("Order ID"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}*/
	public void loadcustomers() {
		try {
			customer_id.removeAll();
			rs=statement.executeQuery("select * from customer");
			while(rs.next()) {
				customer_id.add(rs.getString("Customer ID"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}
	public void loaddrinks() {
		try {
			drinks_id.removeAll();
			rs=statement.executeQuery("select * from drinks");
			while(rs.next()) {
				drinks_id.add(rs.getString("Drinks_ID"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}
	
	

	public void buildGUI() {
		
		
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("submit");
				txtorder_id.setText(null);
				txtcustomer_id.setText(null);
				txtdrinks_id.setText(null);
				txtqty.setText(null);
				txtprice_perqty.setText(null);
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
		//		loadorders();
				loadcustomers();
				loaddrinks();
				
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(5,1));
				 
				 p1.add(lblorder_id);
				 p1.add(txtorder_id);
				 p1.add(lblcustomer_id);
				 p1.add(txtcustomer_id);
				 p1.add(lbldrinks_id);
				 p1.add(txtdrinks_id);
				 p1.add(lblqty);
				 p1.add(txtqty);
				 p1.add(lblprice_perqty);
				 p1.add(txtprice_perqty);
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				
				 p2 = new JPanel(new FlowLayout());
					
					 UserOrderIDList=new List(10);
					 loaduserOrderIDs();
					 p2.add(UserOrderIDList);
					 p2.setBounds(450,150,350,180);   p2.setBackground(Color.cyan) ;
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				 
				 
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO TORDER VALUES("+txtorder_id.getText()+","+txtcustomer_id.getText()+","+txtdrinks_id.getText()+","+txtqty.getText()+","+txtprice_perqty.getText()+")";
					//System.out.println(query);
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");
					
					loaduserOrderIDs();
					//loadorders();
					loadcustomers();
					loaddrinks();
					
					
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("delete");
				txtorder_id.setText(null);
				txtcustomer_id.setText(null);
				txtdrinks_id.setText(null);
				txtqty.setText(null);
				txtprice_perqty.setText(null);
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(5,1));
				 
				 p1.add(lblorder_id);
				 p1.add(txtorder_id);
				 p1.add(lblcustomer_id);
				 p1.add(txtcustomer_id);
				 p1.add(lbldrinks_id);
				 p1.add(txtdrinks_id);
				 p1.add(lblqty);
				 p1.add(txtqty);
				 p1.add(lblprice_perqty);
				 p1.add(txtprice_perqty);
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				
					 
				// p1.setBounds(100,100,400,300);
				
				 p2 = new JPanel(new FlowLayout());
					
					 UserOrderIDList=new List(10);
					 loaduserOrderIDs();
					 p2.add(UserOrderIDList);
					 p2.setBounds(450,150,350,180);   p2.setBackground(Color.cyan) ;
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				 
				 
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 
				 UserOrderIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from torder");
								StringTokenizer st=new StringTokenizer(UserOrderIDList.getSelectedItem(),"->");
								String p=st.nextToken();
								String q=st.nextToken();
								String r=st.nextToken();
								while (rs.next()) 
								{
									if (rs.getString("order_id").equals(p) && rs.getString("customer_id").equals(q) && rs.getString("drinks_id").equals(r))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtorder_id.setText(rs.getString("order_id"));
									txtcustomer_id.setText(rs.getString("customer_id"));
									txtdrinks_id.setText(rs.getString("drinks_id"));
									txtqty.setText(rs.getString("qty"));
									txtprice_perqty.setText(rs.getString("price_perqty"));
									
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
						//StringTokenizer st=new StringTokenizer(UserOrderIDList.getSelectedItem(),"->");
				
					String query="DELETE FROM TORDER WHERE order_id="+txtorder_id.getText()+"";
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loaduserOrderIDs();
			//		loadorders();
					loadcustomers();
					loaddrinks();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("modify");
				txtorder_id.setText(null);
				txtcustomer_id.setText(null);
				txtdrinks_id.setText(null);
				txtqty.setText(null);
				txtprice_perqty.setText(null);
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(5,1));
				 
				 p1.add(lblorder_id);
				 p1.add(txtorder_id);
				 p1.add(lblcustomer_id);
				 p1.add(txtcustomer_id);
				 p1.add(lbldrinks_id);
				 p1.add(txtdrinks_id);
				 p1.add(lblqty);
				 p1.add(txtqty);
				 p1.add(lblprice_perqty);
				 p1.add(txtprice_perqty);
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				
				 p2 = new JPanel(new FlowLayout());
					
					 UserOrderIDList=new List(10);
					 loaduserOrderIDs();
					 p2.add(UserOrderIDList);
					 p2.setBounds(450,150,350,180);  p2.setBackground(Color.cyan) ;
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				 
				 
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				 
				 UserOrderIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from torder");
								StringTokenizer st=new StringTokenizer(UserOrderIDList.getSelectedItem(),"->");
								String p=st.nextToken();
								String q=st.nextToken();
								String r=st.nextToken();
								
								while (rs.next()) 
								{
									if (rs.getString("order_id").equals(p) && rs.getString("customer_id").equals(q) && rs.getString("drinks_id").equals(r))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtorder_id.setText(rs.getString("order_id"));
									txtcustomer_id.setText(rs.getString("customer_id"));
									txtdrinks_id.setText(rs.getString("drinks_id"));
									txtqty.setText(rs.getString("qty"));
									txtprice_perqty.setText(rs.getString("price_perqty"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
								
								 loaduserOrderIDs();
								String qty=JOptionPane.showInputDialog(p,"enter the qty");

								txtqty.setText(qty);
								//int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								//if(a==JOptionPane.YES_OPTION){  
									//StringTokenizer st=new StringTokenizer(UserOrderIDList.getSelectedItem(),"->");
								//String query="update torder set order="+txtorder.getText()+",customer_id="+txtcustomer_id.getText()+",day='"+txtday.getText()+"' WHERE ORDER_ID="+st.nextToken()+"and user_id="+st.nextToken();
								String query="update torder set qty='"+qty+"'where order_id="+txtorder_id.getText();
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loaduserOrderIDs();
				//				loadorders();
								loadcustomers();
								loaddrinks();
								}
								
								
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("ORDER view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.cyan) ;p2.setBackground(Color.cyan) ;
				p.add(p1);p.add(p2);
				 p.setLayout(new FlowLayout());
				
					
				p.setBounds(500,800,300,300);
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						    
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("order Details "); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						        model.addColumn("Order ID");
						        model.addColumn("Customer ID");
						       model.addColumn("Drinks ID");						      
						       model.addColumn("quantity");
						      model.addColumn("priceperquantity");
						       try {
									
									rs=statement.executeQuery("select * from torder");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("order_id"), rs.getString("customer_id"),rs.getString("drinks_id"),rs.getString("qty"),rs.getString("price_perqty")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 300, 300); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(800, 400); 
						      
						        f.setVisible(true); 
						       
					    } 
				        
						
					 
						
						
				 	});
				
			        
				
			}
			
		});
		
	}
	
	
	
}
	
	
	
	
	



