package DrinkB;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Emp{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton insertButton,deleteButton,updateButton,viewButton;
	private JPanel p1,p2,p3,p;
	private JLabel lblemployee_id,lblempname,lblage,lblcontact;
	private JTextField txtemployee_id,txtempname,txtage,txtcontact;
	
	private List MIDList;
	Connection con;ResultSet rs;
	Statement statement;
	private JFrame frame;
	private JMenuItem insert,delete,update,view;
	public Emp(JPanel p,JFrame frame,JMenuItem insert,JMenuItem delete,JMenuItem update,JMenuItem view) 
	{
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		
		this.frame=frame;
		this.insert=insert;
		this.delete=delete;
		this.update=update;
		this.view=view;
		
		lblemployee_id=new JLabel("employee id");
		lblempname=new JLabel("empname");
		lblage=new JLabel("age");
		lblcontact=new JLabel("contact");
		
		
		txtemployee_id=new JTextField(15);
		txtempname=new JTextField(15);
		txtage=new JTextField(8);
		txtcontact=new JTextField(15);
		
		this.p=p;
		
		
		
	}

	public void connectToDB() 
    {
		try {
		  
		
		Connection con=DriverManager.getConnection(  
		"jdbc:oracle:thin:@localhost:1521:xe","it19737110","vasavi");  
		  
		 
		statement=con.createStatement(); 
		statement.executeUpdate("commit");
		
		
		}
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	private void displaySQLErrors(SQLException e) 
	{
		JOptionPane.showMessageDialog(p,"\nSQLException: " + e.getMessage() + "\n"+"SQLState:     " + e.getSQLState() + "\n"+"VendorError:  " + e.getErrorCode() + "\n");
		
		
	}
	public void loadMedIDs() {
		try {
			MIDList.removeAll();
			rs=statement.executeQuery("select employee_id from employee");
			while(rs.next()) {
				MIDList.add(rs.getString("emloyee_id"));
			}
			}
		catch(SQLException e) {
			displaySQLErrors(e);
		}
	}

	public void buildGUI() {
		
		
		
		insert.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				insertButton=new JButton("submit");
				txtemployee_id.setText(null);
				txtempname.setText(null);
				txtage.setText(null);
				txtcontact.setText(null);
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lblemployee_id);
				 p1.add(txtemployee_id);
				 p1.add(lblempname);
				 p1.add(txtempname);
				 p1.add(lblage);
				 p1.add(txtage);
				 p1.add(lblcontact);
				 p1.add(txtcontact);
				
				 p3=new JPanel(new FlowLayout());
				 p3.add(insertButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				 
				
					 
				 
				
				 p2 = new JPanel(new FlowLayout());
					
					 MIDList=new List(10);
					 loadMedIDs();
					 p2.add(MIDList);p2.setBackground(Color.cyan) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				 
				
				 p.setLayout(new BorderLayout());
				
					frame.add(p);
					frame.setSize(800,800);
					frame.validate();
					
				 insertButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					String query="INSERT INTO employee VALUES("+txtemployee_id.getText()+",'"+txtempname.getText()+"',"+txtage.getText()+",'"+txtcontact.getText()+"')";
					
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\ninserted "+i+" rows succesfully");loadMedIDs();
					
					
					
				}
				catch(SQLException insertException){
					displaySQLErrors(insertException);
				}
				
				 }
			
			
				 	});
			}
			});

		delete.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				deleteButton=new JButton("delete");
				
				txtemployee_id.setText(null);
				txtempname.setText(null);
				txtage.setText(null);
				txtcontact.setText(null);
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lblemployee_id);
				 p1.add(txtemployee_id);
				 p1.add(lblempname);
				 p1.add(txtempname);
				 p1.add(lblage);
				 p1.add(txtage);
				 p1.add(lblcontact);
				 p1.add(txtcontact);
				
				 p3=new JPanel(new FlowLayout());
				 p3.add(deleteButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				 
				
					 
				// p1.setBounds(100,100,500,300);
				
				 p2 = new JPanel(new FlowLayout());
					
					 MIDList=new List(10);
					 loadMedIDs();
					 p2.add(MIDList);p2.setBackground(Color.cyan) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				  MIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from employee");
								while (rs.next()) 
								{
									if (rs.getString("employee_id").equals(MIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtemployee_id.setText(rs.getString("employee_id"));
									txtempname.setText(rs.getString("empname"));
									txtage.setText(rs.getString("age"));
									txtcontact.setText(rs.getString("contact"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});				
				 
				 p.setLayout(new BorderLayout());
				
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				
				 deleteButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
				try {
					
					int a=JOptionPane.showConfirmDialog(p,"Are you sure want to delete:");
					if(a==JOptionPane.YES_OPTION){  
					String query="DELETE FROM employee WHERE employee_id="+txtemployee_id.getText()+"";
				
					int i=statement.executeUpdate(query);
					JOptionPane.showMessageDialog(p,"\nDeleted "+i+" rows succesfully");loadMedIDs();
					}
					
					
				}
				catch(SQLException deleteException){
					displaySQLErrors(deleteException);
				}
				
				 }
			
			
				 	});
			}
			});
		
		update.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				JButton updateButton = new JButton("modify");
				txtemployee_id.setText(null);
				txtempname.setText(null);
				txtage.setText(null);
				txtcontact.setText(null);
				
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				
				p1=new JPanel();
			
				 p1.setLayout(new GridLayout(4,2));
				 p1.add(lblemployee_id);
				 p1.add(txtemployee_id);
				 p1.add(lblempname);
				 p1.add(txtempname);
				 p1.add(lblage);
				 p1.add(txtage);
				 p1.add(lblcontact);
				 p1.add(txtcontact);
				 p3=new JPanel(new FlowLayout());
				 p3.add(updateButton);
				 //p1.add(txtf1);
				 p3.setBackground(Color.yellow);
				 p1.setBounds(115,80,300,250);p3.setBounds(200,350,75,35);
				 p1.setBackground(Color.pink) ;
				
				 p2 = new JPanel(new FlowLayout());
					
					 MIDList=new List(10);
					 loadMedIDs();
					 p2.add(MIDList);p2.setBackground(Color.cyan) ;
					 
					 p2.setBounds(450,150,350,180);
				 
				 
				 p. add(p1);p.add(p3);
				 p. add(p2);
				  MIDList.addItemListener(new ItemListener()
					{
						public void itemStateChanged(ItemEvent e) 
						{
							try 
							{
								rs=statement.executeQuery("select * from employee");
								while (rs.next()) 
								{
									if (rs.getString("employee_id").equals(MIDList.getSelectedItem()))
									break;
								}
								if (!rs.isAfterLast()) 
								{
									txtemployee_id.setText(rs.getString("employee_id"));
									txtempname.setText(rs.getString("empname"));
									txtage.setText(rs.getString("age"));
									txtcontact.setText(rs.getString("contact"));
								}
							} 
							catch (SQLException selectException) 
							{
								displaySQLErrors(selectException);
							}
						}
					});			
				 
				 p.setLayout(new BorderLayout());
				
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
					
				
				 updateButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 try {
							 	loadMedIDs();
								String age=JOptionPane.showInputDialog(p,"enter the age");

								txtage.setText(age);
								//int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
								//if(a==JOptionPane.YES_OPTION){  
								String query="update employee set age='"+age+"'where employee_id="+txtemployee_id.getText();
								
								
							//	int a=JOptionPane.showConfirmDialog(p,"Are you sure want to update:");
							//	if(a==JOptionPane.YES_OPTION){  
								//String query="update employee set empname='"+txtempname.getText()+"',age="+txtage.getText()+",contact='"+txtcontact.getText()+"' WHERE employee_id="+MIDList.getSelectedItem();
								
								int i=statement.executeUpdate(query);
								JOptionPane.showMessageDialog(p,"\nupdated "+i+" rows succesfully");loadMedIDs();
								}
								
								
							catch(SQLException deleteException){
								displaySQLErrors(deleteException);
							}
				
				 }
			
			
				 	});
			}
			});
		
		view.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				
				p.removeAll();
				frame.invalidate();
				frame.validate();
				frame.repaint();
				
				Label view1=new Label("employees view");
				//view1.setAlignment(Label.CENTER); 
				Font myFont = new Font("Serif",Font.BOLD,50);
				view1.setFont((myFont));
				viewButton=new JButton("View");
				p1=new JPanel();
				p2=new JPanel();
				p1.add(view1);
				p2.add(viewButton);p1.setBackground(Color.cyan) ;p2.setBackground(Color.cyan) ;
				p.add(p1);p.add(p2); p.setLayout(new FlowLayout());
				frame.add(p);
				frame.setSize(800,800);
				frame.validate();
				 viewButton.addActionListener(new ActionListener() {
					 @Override
						public void actionPerformed(ActionEvent e) {
							// TODO Auto-generated method stub	 
						 JFrame f; 
						      
						    JTable j; 
						
						        f = new JFrame(); 
						  
						  
						        f.setTitle("Medicine details"); 
						        
						       
						        DefaultTableModel model = new DefaultTableModel(); 
						        j = new JTable(model); 
						       model.addColumn("employee id");
						       model.addColumn("empname");
						       model.addColumn("age");
						       model.addColumn("contact");
						      
						      
						       try {
									
									rs=statement.executeQuery("select * from employee");
									while(rs.next()) {
										 model.addRow(new Object[]{rs.getString("employee_id"), rs.getString("empname"),rs.getString("age"),rs.getString("contact")});
									}
									}
								catch(SQLException viewException) {
									displaySQLErrors(viewException);
								}
								j.setEnabled(false);
						        j.setBounds(30, 40, 300, 300); 
						  
						        
						        JScrollPane sp = new JScrollPane(j); 
						        f.add(sp); 
						        
						        f.setSize(800, 400); 
						      
						        f.setVisible(true); 
						       
						        
						    } 
						        
				
				 
			
			
				 	});
				
			        
				
			}
			
		});
		
	}
	
	
	
}
	
	


