package DrinkB;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class DBUI extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private JMenuBar mnu;
	
	private JMenu mnuemployee;
	private JMenu mnucustomer;
	private JMenu mnusupplier;
	private JMenu mnudrinks;
	private JMenu mnutorder;
	private JMenu mnupayments;
	private JMenu mnutransaction;
	
	private JMenuItem insert1,update1,delete1,view1;
	private JMenuItem insert2,update2,delete2,view2;
	private JMenuItem insert3,update3,delete3,view3;
	private JMenuItem insert4,update4,delete4,view4;
	private JMenuItem insert5,update5,delete5,view5;
	private JMenuItem insert6,update6,delete6,view6;
	private JMenuItem insert7,delete7,view7;
	
	private JLabel labelName;

	
	private static JPanel p0,p1;
	
	
	void initialize() {
		mnu=new JMenuBar();
		
		mnuemployee= new JMenu("Employee");
		mnucustomer= new JMenu("Supplier");
		mnusupplier= new JMenu("Customer");
		mnudrinks= new JMenu("Drink");
		mnutorder= new JMenu("Orders");
		mnupayments= new JMenu("Payments");
		mnutransaction= new JMenu("Transactions");
		labelName=new JLabel("DRINK BUCKS");
		 p1=new JPanel();
		p0=new JPanel();
		insert1=new JMenuItem("Insert");
		update1=new JMenuItem("Update");
		delete1=new JMenuItem("Delete");
		view1=new JMenuItem("View");
		insert2=new JMenuItem("Insert");
		update2=new JMenuItem("Update");
		delete2=new JMenuItem("Delete");
		view2=new JMenuItem("View");
		insert3=new JMenuItem("Insert");
		update3=new JMenuItem("Update");
		delete3=new JMenuItem("Delete");
		view3=new JMenuItem("View");
		insert4=new JMenuItem("Insert");
		update4=new JMenuItem("Update");
		delete4=new JMenuItem("Delete");
		view4=new JMenuItem("View");
		insert5=new JMenuItem("Insert");
		update5=new JMenuItem("Update");
		delete5=new JMenuItem("Delete");
		view5=new JMenuItem("View");
		insert6=new JMenuItem("Insert");
		update6=new JMenuItem("Update");
		delete6=new JMenuItem("Delete");
		view6=new JMenuItem("View");
		insert7=new JMenuItem("Insert");
	//	update7=new JMenuItem("Update");
		delete7=new JMenuItem("Delete");
		view7=new JMenuItem("View");
		insert1=new JMenuItem("Insert");
		update1=new JMenuItem("Update");
		delete1=new JMenuItem("Delete");
		view1=new JMenuItem("View");
	}
	void addComponentsToFrame() {
		 mnuemployee.add(insert1);
		 mnuemployee.add(delete1);
		 mnuemployee.add(update1);
		 mnuemployee.add(view1);
		  mnucustomer.add(insert2);
		 mnucustomer.add(delete2);
		 mnucustomer.add(update2);
		 mnucustomer.add(view2);
		 mnusupplier.add(insert3);
		 mnusupplier.add(delete3);
		 mnusupplier.add(update3);
		 mnusupplier.add(view3);
		  mnudrinks.add(insert4);
		 mnudrinks.add(delete4);
		 mnudrinks.add(update4);
		 mnudrinks.add(view4);
		  mnutorder.add(insert5);
		 mnutorder.add(delete5);
		 mnutorder.add(update5);
		 mnutorder.add(view5);
		  mnupayments.add(insert6);
		 mnupayments.add(delete6);
		 mnupayments.add(update6);
		 mnupayments.add(view6);
		  mnutransaction.add(insert7);
		 mnutransaction.add(delete7);
		// mnutransaction.add(update7);
		 mnutransaction.add(view7);
		 mnu.add(mnuemployee);
		 mnu.add(mnucustomer);
		 mnu.add(mnusupplier);
		 mnu.add(mnudrinks);
		 mnu.add(mnutorder);
		 mnu.add(mnupayments);
		 mnu.add(mnutransaction);
		 setJMenuBar(mnu); 
		 p1.add(labelName);p1.setAlignmentY(CENTER_ALIGNMENT); 
		 p1.setBounds(500,500,800,100);	
		p0.add(p1);
		 p0.setBackground(Color.CYAN);
		 add(p0);
	}
void closeWindow(){
		try {
			int a=JOptionPane.showConfirmDialog(this,"Are you sure want to Quit DRINK BUCKS:");
			if(a==JOptionPane.YES_OPTION){  
				JOptionPane.showMessageDialog(this,
					    "Thank you!\nExiting DRINK BUCKS","Quit",
					    JOptionPane.WARNING_MESSAGE);
				System.exit(0);
			}
			else if (a== JOptionPane.NO_OPTION) {
				setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}
			else if (a== JOptionPane.CANCEL_OPTION) {
				setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
			}
		}
			catch(Exception e) {
				System.out.println(e);
				}
	}
	void register() {
		Emp log=new Emp(p0,DBUI.this,insert1,delete1,update1,view1);
		log.buildGUI();
		Cust user=new Cust(p0,DBUI.this,insert3,delete3,update3,view3); 
		user.buildGUI();
		Supp user1=new Supp(p0,DBUI.this,insert2,delete2,update2,view2); 
		user1.buildGUI();
		Drinks d=new Drinks(p0,DBUI.this,insert4,delete4,update4,view4); 
		d.buildGUI();
		Order u=new Order(p0,DBUI.this,insert5,delete5,update5,view5); 
		u.buildGUI();
		pay p=new pay(p0,DBUI.this,insert6,delete6,update6,view6); 
		p.buildGUI();
		trans u_orders=new trans(p0,DBUI.this,insert7,delete7,view7); 
		u_orders.buildGUI();
		addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent we) 
			{ 
				closeWindow();
			} 
		}); 
		
}
public DBUI() {
		initialize();
		addComponentsToFrame();
		register();
	//	setBackground(Color.RED);
		setTitle("DRINKSBUCKS");
		setSize(800,800);
		setVisible(true);
	}
}
